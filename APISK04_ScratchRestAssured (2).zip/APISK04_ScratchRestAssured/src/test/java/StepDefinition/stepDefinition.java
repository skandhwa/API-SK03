package StepDefinition;

import Utilities.FetchDataFromPropertyFile;
import Utilities.TestData;

import static  io.restassured.RestAssured.*;

import org.testng.Assert;

import POJOMapper.CreateUser;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;


public class stepDefinition {
	
	RequestSpecification req;
	RequestSpecification res;
	ResponseSpecification respec;
	Response response;
	String URL_value=FetchDataFromPropertyFile.readDataFromProperty().getProperty("baseURI");
	String URL_value2=FetchDataFromPropertyFile.readDataFromProperty().getProperty("baseURI2");
	String auth_token=FetchDataFromPropertyFile.readDataFromProperty().getProperty("token");
	
	
	
	
	@Given("User requested to hit an application URL")
	public void user_requested_to_hit_an_application_url() {
		
		req=new RequestSpecBuilder().setBaseUri(URL_value)
				.setContentType(ContentType.JSON).build();
		
		
			}	
	@Given("User will pass the payload with all details needed")
	public void user_will_pass_the_payload_with_all_details_needed() {
		
		
		res=given().log().all().relaxedHTTPSValidation().spec(req)
		    .body(CreateUser.createUser());
	   
	}

	@When("the User will hit the specific {string}")
	public void the_user_will_hit_the_specific(String endpoint) {
		
		respec=new ResponseSpecBuilder().expectStatusCode(200).build();
		response=	res.when().post(endpoint).then().log().all().
				spec(respec).extract().response();
	    
	}

	@Then("we are going to validate the response body with a specific {string}")
	public void we_are_going_to_validate_the_response_body_with_a_specific(String status_code) 
	{
	   String s=status_code;
	   int status_code_1=Integer.parseInt(s);
	   int status_code_2= response.getStatusCode();
	   Assert.assertEquals(status_code_2,status_code_1);
	}	
	
	
	
//	@Given("User will pass the payload with authentication details")
//	public void user_will_pass_the_payload_with_authentication_details() 
//	{
//	    res=given().log().all().headers("Authorization",auth_token).relaxedHTTPSValidation()
//	    		.spec(req).body(TestData.payloadData());
//	}
//
//	@When("user will hit the endpoint of the api as {string}")
//	public void user_will_hit_the_endpoint_of_the_api_as(String endpoint) 
//	{
//	   
//		respec=new ResponseSpecBuilder().expectStatusCode(201).build();
//		response=res.when().post(endpoint).then().log().all().spec(respec).extract().response();
//		
//	}
//	
//	@Then("we are going to validate the response body with a specific status code as  {string}")
//	public void we_are_going_to_validate_the_response_body_with_a_specific_status_code_as(String status_code) {
//	   
//		
//		String s=status_code;
//		   int status_code_1=Integer.parseInt(s);
//		   int status_code_2= response.getStatusCode();
//		   Assert.assertEquals(status_code_2,status_code_1);
//		
//	}
	

}
