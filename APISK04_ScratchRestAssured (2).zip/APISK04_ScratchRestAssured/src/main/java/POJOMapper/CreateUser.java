package POJOMapper;

public class CreateUser {
	
	
	public static Object createUser()
	{
		CreateUserPOJO emp=new CreateUserPOJO();
		emp.setName("harry");
		emp.setJob("Manager");
		emp.setLocation("Kolkata");
		emp.setId(12345);
		
		return emp;
	}
	

}
