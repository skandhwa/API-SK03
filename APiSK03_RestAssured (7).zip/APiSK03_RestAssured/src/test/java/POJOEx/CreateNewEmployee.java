package POJOEx;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import static io.restassured.RestAssured.*;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class CreateNewEmployee {

	public static void main(String[] args) throws JsonProcessingException {
		
		EmployeePOJO emp=new EmployeePOJO();
		
		emp.setName("Harry");
		emp.setLocation("Delhi");
		emp.setSalary(50000f);
		emp.setJob("QA lead");
		
		ObjectMapper obj=new ObjectMapper();
		
	String empJson=	obj.writerWithDefaultPrettyPrinter().
			writeValueAsString(emp);
	
	RequestSpecification req=new RequestSpecBuilder().
			setBaseUri("https://httpbin.org")
			.setContentType(ContentType.JSON).build();
	
	RequestSpecification respec=given().log().all().spec(req).body(empJson);
	
	ResponseSpecification res=new ResponseSpecBuilder().expectStatusCode(200).build();
	
	 Response response=respec.when().post("post").then().log().all().
	spec(res).extract().response();
	 
	 String ResponseString=response.asString();
	
	System.out.println(ResponseString);
	
	
	///Deserialization
	
	
	EmployeePOJO empObj=obj.readValue(empJson,EmployeePOJO.class);
	
	System.out.println();
	System.out.println("Doing Deserialization");
	System.out.println(empObj.getName());
	System.out.println(empObj.getLocation());
	System.out.println(empObj.getJob());	
		
		
		
		
		
		

	}

}
