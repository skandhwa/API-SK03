package POJOEx4;

import static io.restassured.RestAssured.given;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import ComplexPoJoEx.Employee1POJO;
import ComplexPoJoEx.EmployeeAddress;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class CreateNewEmployee4 {

	public static void main(String[] args) throws JsonProcessingException {
		
		EmployeeAddress empaddress=new EmployeeAddress();
		empaddress.setCity("Kolkata");
		empaddress.setState("WB");
		empaddress.setStreet("PR lane");
		empaddress.setPincode(713304);
		
		List<String> banks=new ArrayList<String>();
		banks.add("SBI");
		banks.add("HDFC");
		banks.add("ICICI");
		
		EmployeePOJO4 emp=new EmployeePOJO4();
		
		emp.setName("Harry");
		emp.setLocation("Delhi");
		emp.setSalary(50000f);
		emp.setJob("QA lead");
		emp.setEmpaddress(empaddress);
		emp.setBank(banks);
		
		ObjectMapper obj=new ObjectMapper();
	String empJson=	obj.writerWithDefaultPrettyPrinter().writeValueAsString(emp);
		
	RequestSpecification req=new RequestSpecBuilder().
			setBaseUri("https://httpbin.org")
			.setContentType(ContentType.JSON).build();
	
	RequestSpecification respec=given().log().all().spec(req).body(empJson);
	
	ResponseSpecification res=new ResponseSpecBuilder().expectStatusCode(200).build();
	
	 Response response=respec.when().post("post").then().log().all().
	spec(res).extract().response();
	 
	 String ResponseString=response.asString();
	
	System.out.println(ResponseString);
	
	System.out.println();
	System.out.println();
	System.out.println();
	
	EmployeePOJO4 responseobj=obj.readValue(empJson, EmployeePOJO4.class);
	
	System.out.println("List of all the bank account details are"+responseobj.getBank());
	System.out.println("Address details f employee are"+responseobj.getEmpaddress());
		
		
		
		
		
		
		
		
		
		
		

	}

}
