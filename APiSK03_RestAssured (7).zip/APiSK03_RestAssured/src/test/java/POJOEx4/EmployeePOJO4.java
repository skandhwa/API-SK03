package POJOEx4;

import java.util.List;

import ComplexPoJoEx.EmployeeAddress;

public class EmployeePOJO4 {
	
	private String name;
	private String job;
	private double Salary;
	private String location;
	private EmployeeAddress empaddress;
	private List<String> bank;
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public double getSalary() {
		return Salary;
	}
	public void setSalary(double salary) {
		Salary = salary;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public EmployeeAddress getEmpaddress() {
		return empaddress;
	}
	public void setEmpaddress(EmployeeAddress empaddress) {
		this.empaddress = empaddress;
	}
	public List<String> getBank() {
		return bank;
	}
	public void setBank(List<String> bank) {
		this.bank = bank;
	}
	
	
	

}
