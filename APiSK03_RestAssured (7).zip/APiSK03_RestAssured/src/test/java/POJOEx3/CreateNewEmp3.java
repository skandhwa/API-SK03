package POJOEx3;

import static io.restassured.RestAssured.given;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class CreateNewEmp3 {

	public static void main(String[] args) throws JsonProcessingException {
		
		EmployeePOJO2 emp=new EmployeePOJO2();
		emp.setName("Harry");
		emp.setLocation("Delhi");
		emp.setSalary(50000f);
		emp.setJob("QA lead");
		
		EmployeePOJO2 emp1=new EmployeePOJO2();
		emp1.setName("Tom");
		emp1.setLocation("Kolkata");
		emp1.setSalary(80000f);
		emp1.setJob("QA Analyst");
		
		EmployeePOJO2 emp2=new EmployeePOJO2();
		emp2.setName("Larry");
		emp2.setLocation("Mumbai");
		emp2.setSalary(90000f);
		emp2.setJob("QA Manager");
		
		List<EmployeePOJO2> li=new ArrayList<EmployeePOJO2>();
		li.add(emp);
		li.add(emp1);
		li.add(emp2);
		
		
		
		ObjectMapper obj=new ObjectMapper();
		
		String empJson=	obj.writerWithDefaultPrettyPrinter().
				writeValueAsString(li);
		
		RequestSpecification req=new RequestSpecBuilder().
				setBaseUri("https://httpbin.org")
				.setContentType(ContentType.JSON).build();
		
		RequestSpecification respec=given().log().all().spec(req).body(empJson);
		
		ResponseSpecification res=new ResponseSpecBuilder().expectStatusCode(200).build();
		
		 Response response=respec.when().post("post").then().log().all().
		spec(res).extract().response();
		 
		 String ResponseString=response.asString();
		
		System.out.println(ResponseString);
		
		
		
		
		

	}

}
