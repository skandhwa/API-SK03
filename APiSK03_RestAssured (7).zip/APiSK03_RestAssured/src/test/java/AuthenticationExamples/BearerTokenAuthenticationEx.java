package AuthenticationExamples;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;

import java.util.LinkedHashMap;
import java.util.Map;

public class BearerTokenAuthenticationEx {

	public static void main(String[] args) {
		
		String token="Bearer c555d086217024aa3cb7d70695253766f9f011dbbbdfe9c45fac2a474724d2d9";
		Map<String,Object>mp=new LinkedHashMap<String,Object>();
		mp.put("name", "raymond");
		mp.put("gender", "male");
		mp.put("email", "raymoynd123d@gmail.com");
		mp.put("status", "active");
		
		
		
		RestAssured.baseURI="https://gorest.co.in";
	String Response=	given().log().all().
			headers("Content-Type","application/json")
		.headers("Authorization",token)
		.body(mp)
		.when().post("public/v2/users")
		.then().log().all().
		extract().response().asString();
	
	
	System.out.println(Response);
		
		

	}

}
