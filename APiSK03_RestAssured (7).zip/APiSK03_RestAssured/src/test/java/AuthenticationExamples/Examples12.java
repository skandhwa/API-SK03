package AuthenticationExamples;

public class Examples12 {

	public static void main(String[] args) {
		
		System.out.println(5+2*3);
		
		short y=1262;
		
	}

}
