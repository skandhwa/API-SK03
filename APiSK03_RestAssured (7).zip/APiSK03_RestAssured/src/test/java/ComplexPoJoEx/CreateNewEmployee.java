package ComplexPoJoEx;

import static io.restassured.RestAssured.given;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class CreateNewEmployee {

	public static void main(String[] args) throws JsonProcessingException {
		
		EmployeeAddress empaddress=new EmployeeAddress();
		empaddress.setCity("Kolkata");
		empaddress.setState("WB");
		empaddress.setStreet("PR lane");
		empaddress.setPincode(713304);
		
		Employee1POJO emp=new Employee1POJO();
		
		emp.setName("Harry");
		emp.setLocation("Delhi");
		emp.setSalary(50000f);
		emp.setJob("QA lead");
		emp.setEmpaddress(empaddress);
		
		
		
		
		ObjectMapper obj=new ObjectMapper();
		String empJson=	obj.writerWithDefaultPrettyPrinter().
				writeValueAsString(emp);
		
		RequestSpecification req=new RequestSpecBuilder().
				setBaseUri("https://httpbin.org")
				.setContentType(ContentType.JSON).build();
		
		RequestSpecification respec=given().log().all().spec(req).body(empJson);
		
		ResponseSpecification res=new ResponseSpecBuilder().expectStatusCode(200).build();
		
		 Response response=respec.when().post("post").then().log().all().
		spec(res).extract().response();
		 
		 String ResponseString=response.asString();
		
		System.out.println(ResponseString);
		
		
		
		
		
		

	}

}
