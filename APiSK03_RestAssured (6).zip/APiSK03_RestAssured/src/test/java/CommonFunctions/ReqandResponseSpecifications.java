package CommonFunctions;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class ReqandResponseSpecifications {
	
	
	
	public static RequestSpecification requestMethod()
	{
		RequestSpecification req=new RequestSpecBuilder()
				.setBaseUri("https://reqres.in/")
				.setContentType(ContentType.JSON).build();
		
		return req;
	}
	
	public static ResponseSpecification responseMethod(int statusCode)
	{
		ResponseSpecification respec= new ResponseSpecBuilder()
				.expectStatusCode(statusCode).expectContentType(ContentType.JSON)
				.expectHeader("Server","cloudflare").build();
		
		return respec;
	}
	

}
