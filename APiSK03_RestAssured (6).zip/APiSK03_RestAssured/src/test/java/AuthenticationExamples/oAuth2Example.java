package AuthenticationExamples;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

import static io.restassured.RestAssured.*;

public class oAuth2Example {

	String Access_Token;
	
	@Test(priority=1)
	public void generateAccesstoken()
	{
		
	String client_id="ASyStlg4z4BjlmHNrXnDSLwFzY6j8NwPPE16opmTNUxHYf1IXRThQgb3ZN9uWeq3byeJPHlGXp_Gk2f7"; 
	String client_secret_id="ECKYHfIutJTW9x6PgRFePjsHJPH5MAomf34tbLqp7xmeckGaZGwM083k7ZHrY1cSnW18IYZcNKOH_chu";
		RestAssured.baseURI="https://api-m.sandbox.paypal.com";
	String Response=	given().log().all().auth().preemptive().basic(client_id,client_secret_id)
		.param("grant_type", "client_credentials")
		.when().post("/v1/oauth2/token")
		.then().log().all().extract().response().asString();
	
	System.out.println(Response);
	
	JsonPath js=new JsonPath(Response);
	 Access_Token=js.getString("access_token");
	 System.out.println("The acess token is "+Access_Token);
	
		
		
		
	}
	
	@Test(priority=2)
	public void accessResourceServer()
	{
		
		RestAssured.baseURI="https://api-m.sandbox.paypal.com";
	String Resource_details=	given().log().all().queryParam("page",3).queryParam("page_size", 4)
		.queryParam("total_count_required",true)
		.auth().oauth2(Access_Token)
		.when().get("v1/invoicing/invoices")
		.then().log().all().assertThat().statusCode(200).extract().response().asString();
	
	System.out.println(Resource_details);
		
		
	}
	
	

}
