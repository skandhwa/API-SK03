package MyPractice;

import java.util.Scanner;

public class TakingInputasString {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a string");
		String name=sc.next();
		int x=name.length();
		System.out.println("The length of the string is  "+x);
		

	}

}
