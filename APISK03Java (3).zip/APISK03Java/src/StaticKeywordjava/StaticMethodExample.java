package StaticKeywordjava;

class Employee3
{
	static void display()
	{
		System.out.println("Hello");
	}
}


public class StaticMethodExample {

	public static void main(String[] args) {
		
		Employee3.display();
		

	}

}
