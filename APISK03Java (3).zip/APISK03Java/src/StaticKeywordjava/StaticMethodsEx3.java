package StaticKeywordjava;

public class StaticMethodsEx3 {
	
	int message(int x,int y)
	{
		return x+y;
	}
	
	static String display(String n,String m)
	{
		return n+" " +m;
	}
	
	

	public static void main(String[] args) {
		
		StaticMethodsEx3 obj=new StaticMethodsEx3();
	System.out.println(obj.message(5, 6));	
	
	
	
System.out.println(display("John", "Dsouza"));	
	
		

	}

}
