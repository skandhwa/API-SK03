package StaticKeywordjava;

class Employee2
{
	int id;
	String name;	
	static String companyName="TCS";
     

Employee2(int i,String n)
{
	id=i;
	name=n;
	
}

static void change()
{
	companyName="Infosys";
	
	
	
}




void display()
{
	System.out.println(id+"  "+name+" "+companyName);
}
}

public class StaticVariable {

	public static void main(String[] args) {
		Employee2.change();
		
		Employee2 obj=new Employee2(2314,"John");
		Employee2 obj1=new Employee2(3314,"Harry");
		obj.display();
		obj1.display();
		
	}
		
		
		

	}


