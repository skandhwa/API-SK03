package OOpsConceptandSuperThis;

class Test8
{
	void m()
	{
		System.out.println("Hello");
	}
	
	void n()
	{
		this.m();
		System.out.println("Hi");
	}
}

public class InvokingCurrentClassMethodThis {

	public static void main(String[] args) {
		Test8 obj=new Test8();
		obj.n();
		

	}

}
