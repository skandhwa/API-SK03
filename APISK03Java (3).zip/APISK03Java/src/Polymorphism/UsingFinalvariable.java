package Polymorphism;

class Car
{
	static final int speed=120;
	void test()
	{
		//speed=140;
		System.out.println(speed);
	}
	
}
public class UsingFinalvariable {

	public static void main(String[] args) {
	
		
		Car obj=new Car();
		obj.test();

	}

}
