package MyPractice;

public class LogicalNotOperators {

	public static void main(String[] args) {
		
		int x=5;
		int y=6;
		
		if(!(x>y))
		{
		System.out.println("Hello");
		}
		else
		{
			System.out.println("Hi");
		}
		

	}

}
