package AbstractionInJava;

abstract class Employee6
{
	abstract void salary();
	void test()
	{
		System.out.println("Hello");
	}
	
	void message()
	{
		System.out.println("Hi");
	}
	
}

class Person7 extends Employee6
{
	void salary()
	{
		System.out.println("hello how r u");
	}
}
public class UsingAbstractClass {

	public static void main(String[] args) {
		Person7 obj=new Person7();
		obj.salary();
		obj.test();
        obj.message();
		

	}

}
