package Polymorphism;

class Bank
{
	int getROI(int x,int y)
	{
		return x+y;
	}
}

class SBI extends Bank
{
	
	
	int getROI(int x,int y)
	{
		return x+y;
	}
	
//	void display()
//	{
//		super.getROI(23, 14);
//	}
	
	
}

class HDFC extends Bank
{
	int getROI(int x,int y)
	{
		return x+y;
	}
}

public class MethodOverridingEx {

	public static void main(String[] args) {
		
		HDFC obj=new HDFC();
		obj.getROI(3,4);
		
		SBI obj1=new SBI();
		obj1.getROI(4,4);
		
		
		

	}

}
