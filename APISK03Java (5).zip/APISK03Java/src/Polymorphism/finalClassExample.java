package Polymorphism;


final class Employee5
{
	static void display()
	{
		System.out.println("hello");
	}
}

class Person3 extends Employee5
{
	void test()
	{
		System.out.println("Hi");
	}
}



public class finalClassExample {

	public static void main(String[] args) {
		
		Person3 obj=new Person3();
		obj.display();
		obj.test();
		

	}

}
