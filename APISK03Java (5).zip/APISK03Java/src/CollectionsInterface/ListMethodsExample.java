package CollectionsInterface;

import java.util.ArrayList;
import java.util.List;

public class ListMethodsExample {

	public static void main(String[] args) {
		
		List<Object> li=new ArrayList<Object>();
		li.add(23);
		li.add(35);
		li.add(56);
		li.add('A');
		li.add(false);
		li.add("Saurabh");
		
		int k=li.size();
		System.out.println("size of array list is "+k);
		
		List<Object> li2=new ArrayList<Object>();
		li2.add(13);
		li2.add(55);
		li2.add(96);
		li2.add('A');
		li2.add(true);
		li2.add("Gaurabh");
		
		li.set(2,"Tom");
		
		for(Object x:li)
		{
			System.out.println(x);
		}
		System.out.println("After deleting elements are");
		
		//li.remove(3);
		for(Object x:li)
		{
			System.out.println(x);
		}
		
		//li.clear();
		System.out.println("Removing all the elements from list");
		
		for(Object x:li)
		{
			System.out.println(x);
		}
		
		li.addAll(li2);
		
		System.out.println();
		System.out.println();
		System.out.println("After Merging elements are ");
		for(Object z:li)
		{
			System.out.println(z);
		}
		
		

	}

}
