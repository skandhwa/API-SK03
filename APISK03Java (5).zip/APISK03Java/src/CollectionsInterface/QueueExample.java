package CollectionsInterface;

import java.util.PriorityQueue;
import java.util.Queue;

public class QueueExample {

	public static void main(String[] args) {
		
		Queue<Integer> q1=new PriorityQueue<Integer>();
		q1.add(45);
		q1.add(76);
		q1.add(99);
		
		for(int x:q1)
		{
			System.out.println(x);
		}
		

		q1.remove();
		
		System.out.println("after removing elements are");

		for(int x:q1)
		{
			System.out.println(x);
		}
		
		
		
	}

}
