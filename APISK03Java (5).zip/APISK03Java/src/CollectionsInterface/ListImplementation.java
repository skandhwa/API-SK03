package CollectionsInterface;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ListImplementation {

	public static void main(String[] args) {
		
		List<Object> li=new ArrayList<Object>();
		li.add(23);
		li.add(35);
		li.add(56);
		li.add('A');
		li.add(false);
		li.add("Saurabh");
		li.add(null);
		li.add('A');
		li.add(false);
		li.add("Saurabh");
		li.add(null);
		
		for(Object x:li)
		{
			System.out.println(x);
		}
		System.out.println("searching an element for 4th index "+li.get(4));
		
		li.remove(2);
		;
		
	boolean flag=	li.contains(90);
	System.out.println("Does it contains null value ?  "  +flag);
		
		
		System.out.println();
		System.out.println();
		
		Iterator itr=li.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		
		System.out.println();
		System.out.println();
		System.out.println(li);
		
		
		
		
		
		

	}

}
