package CollectionsInterface;

import java.util.Vector;

public class VectorEx1 {

	public static void main(String[] args) {
		
		Vector<Integer> v1=new Vector<Integer>();
		v1.add(23);
		v1.add(56);
		v1.add(78);
		
		for(int x:v1)
		{
			System.out.println(x);
		}
		

	}

}
