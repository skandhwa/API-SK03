package CollectionsInterface;

import java.util.Stack;

public class StackExample {

	public static void main(String[] args) {
		
		Stack<Integer> s1=new Stack<Integer>();
		s1.push(34);
		s1.push(56);
		s1.push(84);
		s1.push(95);
		
		for(int x:s1)
		{
			System.out.println(x);
		}
		
		s1.pop();
		System.out.println("After popping");
		for(int x:s1)
		{
			System.out.println(x);
		}
		

	}

}
