package CollectionsInterface;

import java.util.LinkedList;
import java.util.List;

public class UslingLinkedList {

	public static void main(String[] args) {
		
		List<Object> li=new LinkedList<Object>();
		li.add(12);
		li.add(35);
		li.add(56);
		li.add('A');
		li.add(false);
		li.add("Saurabh");
		
		for(Object x:li)
		{
			System.out.println(x);
		}
		

	}

}
