package CollectionsInterface;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class HashSetExample1 {

	public static void main(String[] args) {
		
		Set<String> s1=new HashSet<String>();
		s1.add("Mango");
		s1.add("Apple");
		s1.add("Watermelon");
		s1.add("Orange");
		s1.add("Apple");
		s1.add(null);
		s1.add(null);
		for(String x:s1)
		{
			System.out.println(x);
		}
		
		System.out.println();
		
		System.out.println("Using iterator");
		
		Iterator<String>itr=s1.iterator();
		
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		
		
		
		
		

	}

}
