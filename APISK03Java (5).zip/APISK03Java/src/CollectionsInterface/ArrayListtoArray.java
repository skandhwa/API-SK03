package CollectionsInterface;

import java.util.ArrayList;
import java.util.List;

public class ArrayListtoArray {

	public static void main(String[] args) {
		
		List<String> li=new ArrayList<String>();
		li.add("Melon");
		li.add("Apple");
		li.add("Grapes");
		li.add("Oranges");
		
		Object []arr=new String[li.size()];
		li.toArray(arr);
		
		for(Object x:arr)
		{
			System.out.println(x);
		}
		
		
		
	}

}
