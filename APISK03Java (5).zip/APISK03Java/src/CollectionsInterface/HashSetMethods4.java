package CollectionsInterface;

import java.util.HashSet;
import java.util.Set;

public class HashSetMethods4 {

	public static void main(String[] args) {
		
		
		Set<String> s1=new HashSet<String>();
		s1.add("Mango");
		s1.add("Apple");
		s1.add("Watermelon");
		s1.add("Orange");
		
		Set<String> s2=new HashSet<String>();
		s2.add("Kiwi");
		s2.add("Apple");
		s2.add("Banana");
		s2.add("Orange");
		
//		s1.retainAll(s2);
//		for(String x:s1)
//		{
//			System.out.println(x);
//		}
		
		s1.removeAll(s2);
		for(String x:s1)
			{
				System.out.println(x);
			}
		
		
		
		

	}

}
