package CollectionsInterface;

import java.util.HashSet;
import java.util.Set;

public class HashSetMethod1 {

	public static void main(String[] args) {
		
		Set<String> s1=new HashSet<String>();
		s1.add("Mango");
		s1.add("Apple");
		s1.add("Watermelon");
		s1.add("Orange");
		
		s1.remove("Mango");
		for(String x:s1)
		{
			System.out.println(x);
		}
		
		
		Set<String> s2=new HashSet<String>();
		s2.add("Kiwi");
		s2.add("Lemon");
		s2.add("Grapes");
		s2.add("Pineapple");
		s2.add("Watermelon");
		
//		s1.addAll(s2);
//		System.out.println();
//		System.out.println("After merging elements are");
//		System.out.println();
//		for(String x:s1)
//		{
//			System.out.println(x);
//		}
		
		System.out.println();
		System.out.println();
		System.out.println("After using remove method");
		
		s1.removeAll(s2);
		
		for(String x:s1)
			{
				System.out.println(x);
			}
		
		
		

	}

}
