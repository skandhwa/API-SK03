package CollectionsInterface;

import java.util.HashSet;
import java.util.Set;

public class HashSetMethods3 {

	public static void main(String[] args) {
	
		Set<String> s1=new HashSet<String>();
		s1.add("Mango");
		s1.add("Apple");
		s1.add("Watermelon");
		s1.add("Orange");
		
		int p=s1.size();
		System.out.println("Size of the set is "+p);
		
	boolean flag=	s1.contains("banana");
	System.out.println(flag);
	
	s1.clear();
	System.out.println("After clearing the elements are");
	
	for(String x:s1)
	{
		System.out.println(x);
	}
	
	boolean flag2=	s1.isEmpty();
	System.out.println("Is the set empty "+flag2);
	
	
	
		
		

	}

}
