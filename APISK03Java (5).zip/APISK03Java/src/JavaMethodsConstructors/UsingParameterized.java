package JavaMethodsConstructors;

class Test2
{
	int x;
	int y;
	int z;
	
	Test2(int a,int b,int c)
	{
		x=a;
		y=b;
		z=c;
		
	}
	
	void display()
	{
		System.out.println(x);
		System.out.println(y);
		System.out.println(z);
	}
}



public class UsingParameterized {

	public static void main(String[] args) {
		
		Test2 obj=new Test2(12,13,14);
		obj.display();
		

	}

}
