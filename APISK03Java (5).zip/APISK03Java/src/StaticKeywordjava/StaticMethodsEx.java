package StaticKeywordjava;

public class StaticMethodsEx {
	
	static int square(int x)
	{
		return x*x;
	}
	

	public static void main(String[] args) {
		
		
	System.out.println(StaticMethodsEx.square(4));	

	}

}
