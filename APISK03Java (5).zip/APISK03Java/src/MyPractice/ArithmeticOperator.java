package MyPractice;

public class ArithmeticOperator {

	public static void main(String[] args) {
		
		
		int a=56%6;//2
		int b=56/6;//9
		System.out.println(a);
		System.out.println(b);

	}

}
