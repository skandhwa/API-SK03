package MyPractice;

public class ifElse {

	public static void main(String[] args) {
		
		int a=10;
		int b=14;
		int c=20;
		
		if(a>=b || c<=a || b<=c)
		{
			System.out.println("hello");
		}
		else
		{
			System.out.println("Hi");
		}
		

	}

}
