package StringInJava;

public class StringMethods1 {

	public static void main(String[] args) {
		
		String str="Republic";
		
	char ch=	str.charAt(2);
	
	System.out.println(ch);
	
	int x=str.length();
	System.out.println(x);
	
	String str1=str.substring(4);
	System.out.println(str1);
	
	String str2=str.substring(3,7);
	System.out.println(str2);
	
		

	}

}
