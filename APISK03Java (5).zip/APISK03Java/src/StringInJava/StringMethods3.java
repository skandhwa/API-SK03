package StringInJava;

public class StringMethods3 {

	public static void main(String[] args) {
		
		String str="Java is a Robust Programming language";
		String str1=str.replace('a','b');
		System.out.println(str1);
		
		
		String str2="Java is a Robust Programming language";
		String str3=str2.replaceAll("Java","python");
		System.out.println(str3);
		

	}

}
