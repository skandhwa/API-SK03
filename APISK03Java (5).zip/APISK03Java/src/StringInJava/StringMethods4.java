package StringInJava;

public class StringMethods4 {

	public static void main(String[] args) {
		
		String str="India is a democratic country";
	String []words=	str.split(" ");
	
	for(String x:words)
	{
		System.out.println(x);
	}
		
	
	String str1="India @ republic # country % Asia";
String[]words2=	str1.split("#");
System.out.println(words2[1]);
	
		
		

	}

}
