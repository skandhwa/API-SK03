package StringInJava;

public class StringMethods2 {

	public static void main(String[] args) {
		
		String str="Welcome";
		String str1="welcome";
		
	boolean flag=	str.equals(str1);
	System.out.println(flag);
	
	boolean flag1=str.equalsIgnoreCase(str1);
	System.out.println(flag1);
	
	String str2="saurbh";
//boolean flag2=	str2.isEmpty();
//System.out.println("Is the string emplty "+flag2);
	
boolean flag5=	str2.isBlank();
System.out.println("Is String blank "+flag5);
		

	}

}
