package ExceptionHandlinginJava;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;

public class ThrowingCheckedExceptionEx {
	
	public static void FileCheck(boolean flag) throws FileNotFoundException
	{
		if(flag==false)
		{
		
		FileReader f=new FileReader("C:\\Users\\saura\\OneDrive\\Documents\\Class Link 13th May.txt");
		BufferedReader fileip=new BufferedReader(f);
		throw new FileNotFoundException();
		}
		
		else
		{
			FileReader f=new FileReader("C:\\Users\\saura\\OneDrive\\Documents\\Class Link 13th May.txt");
			BufferedReader fileip=new BufferedReader(f);
			System.out.println("I can read the file");
		}
		
	}
	
	

	public static void main(String[] args) throws FileNotFoundException {
		
		FileCheck(true);
		
		
	}

}
