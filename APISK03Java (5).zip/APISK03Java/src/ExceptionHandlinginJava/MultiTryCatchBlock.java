package ExceptionHandlinginJava;

public class MultiTryCatchBlock {

	public static void main(String[] args) {
		
		try
		{
			String str=null;
			int k=str.length();
			System.out.println("Length of string is "+k);
			
			
			int x[]=new int [5];
			x[0]=12;
			x[1]=22;
			x[2]=32;
			x[3]=42;
			x[4]=52;
			x[5]=62;
			x[6]=72;
			
			for(int i=0;i<x.length;i++)
			{
				System.out.println(x[i]);
			}
			
			int p=10;
			int y=p/0;
			System.out.println(y);
			
			
			
		
		}
		
		catch(ArithmeticException e)
		{
			System.out.println("caught with "+e);
		}
		
		catch(ArrayIndexOutOfBoundsException m)
		{
			System.out.println("caught with "+m);
		}
		
		catch(NullPointerException n)
		{
			System.out.println("caught with "+n);
		}
		
		

	}

}
