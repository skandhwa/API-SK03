package ExceptionHandlinginJava;

public class UsingFinallyBlock {

	public static void main(String[] args) {
		
		try
		{
		int x=10;
		int y=x/2;
		System.out.println(y);
		}
		
		
		
		finally
		{
			int a=10;
			int b=20;
			int c=a+b;
			System.out.println(c);
			
		}
		
		int d=20;
		int e=d*10;
		System.out.println(e);
		
		
		
		

	}

}
