package ExceptionHandlinginJava;

public class UsingThrowsException {

	public static void main(String[] args) throws InterruptedException {
		
		
		Thread.sleep(4000);

	}

}
