package ExceptionHandlinginJava;

public class ExceptionExample2 {

	public static void main(String[] args) {
		
		try
		{
		
		int x[]=new int [5];
		x[0]=12;
		x[1]=22;
		x[2]=32;
		x[3]=42;
		x[4]=52;
		x[5]=62;
		x[6]=72;
		
		for(int i=0;i<x.length;i++)
		{
			System.out.println(x[i]);
		}
		
		}
		
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("caught with "+e);
		}
		
		
		
		
		int a=10;
		int b=20;
		int c=a+b;
		System.out.println(c);

	}

}
