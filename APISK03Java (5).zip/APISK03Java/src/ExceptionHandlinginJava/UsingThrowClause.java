package ExceptionHandlinginJava;

public class UsingThrowClause {
	
	public static void validateAge(int age)
	{
		if(age<18)
		{
			throw new ArithmeticException("You Are not elligible to vote");
		}
		else
		{
			System.out.println("You are elligible to vote");
		}
	}
	
	public static void main(String[] args) {
		
		UsingThrowClause.validateAge(21);
		int a=10;
		int b=20;
		int c=a+b;
		System.out.println(c);
		
		
		
		
		

	}

}
