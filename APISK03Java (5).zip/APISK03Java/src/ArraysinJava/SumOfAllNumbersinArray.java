package ArraysinJava;

public class SumOfAllNumbersinArray {

	public static void main(String[] args) {
		
		int []b= {23,12,34,56};
		int sum=0;
		
		for(int i=0;i<b.length;i++)
		{
			sum=sum+b[i];
		}
		
		
		System.out.println("The sum is "+sum);

	}

}
