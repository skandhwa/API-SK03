package ArraysinJava;

import java.util.Arrays;

public class ArrayMethods1 {

	public static void main(String[] args) {
		
		int a[]= {93,34,31,45,67,88};
		int b[]= {193,34,31,45,67,88};
		
		int x=Arrays.compare(a, b);
		System.out.println(x);
		
	boolean flag=	Arrays.equals(a,b);
	System.out.println(flag);

	
Arrays.sort(a);
System.out.println("Array after sorting is ");

for(int z:a)
{
	System.out.println(z);
}
	
	}

}
