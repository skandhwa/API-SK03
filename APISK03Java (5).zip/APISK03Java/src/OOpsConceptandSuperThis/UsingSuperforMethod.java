package OOpsConceptandSuperThis;

class Test6a
{
	void sleep()
	{
		System.out.println("Superclass I am sleeping");
	}
}

class Test6b extends Test6a
{
	void sleep()
	{
		System.out.println("Subclass I am sleeping");
	}
	void eat()
	{
		System.out.println("I am eating");
	}
	void play()
	{
		System.out.println("I am playing");
	}
	void leisure()
	{
		super.sleep();
		sleep();
		eat();
		play();
		
		
		
	}
	
}

public class UsingSuperforMethod {

	public static void main(String[] args) {
		
		Test6b obj=new Test6b();
		obj.leisure();
		

	}

}
