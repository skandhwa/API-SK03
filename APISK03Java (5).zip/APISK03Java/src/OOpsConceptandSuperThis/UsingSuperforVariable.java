package OOpsConceptandSuperThis;

class Test4a
{
	String colour="pink";
}


class Test5 extends Test4a
{
	String colour="red";
}

class Test6 extends Test5
{
	String colour="blue";
	void display()
	{
		System.out.println("Subclasses variable is "+colour);
		System.out.println("Super classes variable is "+super.colour);
	}
	
	}

public class UsingSuperforVariable {

	public static void main(String[] args) {
		
		Test6 obj=new Test6();
		obj.display();
		

	}

}
