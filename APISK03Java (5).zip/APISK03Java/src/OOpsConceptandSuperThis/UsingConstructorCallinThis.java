package OOpsConceptandSuperThis;

class Student7
{
	int roll;
	String name;
	String address;
	char behaviour;
	Student7(int roll,String name,String address)
	{
		this.roll=roll;
		this.name=name;
		this.address=address;
	}
	Student7(int roll,String name,String address,char behaviour)
	{
		this(roll,name,address);
		this.behaviour=behaviour;
	}
	
	
	
	void display()
	{
		System.out.println(roll+" "+name+" "+address +"  "+behaviour);
	}
	}



public class UsingConstructorCallinThis {

	public static void main(String[] args) {
		
		Student7 obj=new Student7(1234,"Mohan","Delhi");
		Student7 obj1=new Student7(1234,"Mohan","Delhi",'A');
		obj.display();
		obj1.display();
		

	}

}
