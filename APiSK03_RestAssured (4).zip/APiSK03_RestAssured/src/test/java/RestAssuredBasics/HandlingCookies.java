package RestAssuredBasics;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;

import PayloadData.CookiesData;

public class HandlingCookies {

	public static void main(String[] args) {
		
		RestAssured.baseURI="https://postman-echo.com";
	String Response=	given().log().all().cookies(CookiesData.SetCookiesData())
		.when().post("cookies/set").then().log().all().
		
		
		extract().response().asString();
	
	System.out.println(Response);
		
		
		

	}

}
