package RestAssuredBasics;

import static io.restassured.RestAssured.given;

import org.testng.Assert;

import PayloadData.Payload1;

import static io.restassured.RestAssured.*;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

public class UsingPost {

	public static void main(String[] args) {
		
		String Current_Date="2024-07-24";
		
		RestAssured.baseURI="https://reqres.in";
		
		String Response=	
				given().log().all().header("Connection","keep-alive")
				.header("Content-Type","application/json")
				.body(Payload1.addDetails("Harry","Manager"))
			.when().post("api/users")
			.then().log().all().assertThat().statusCode(201).extract().response()
			.asString();
		
		System.out.println(Response);
		
		JsonPath js=new JsonPath(Response);
	String CreatedDate=	js.getString("createdAt");
	
String[]ch=	CreatedDate.split("T");
System.out.println(ch[0]);
System.out.println(ch[1]);

Assert.assertEquals(ch[0], Current_Date);
System.out.println("Test Case passed");

		
		
		
		
		
		

	}

}
