package BasicsofSerializationDeserialization;

import org.testng.Assert;
import org.testng.annotations.Test;
import static io.restassured.RestAssured.*;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import net.minidev.json.JSONObject;

public class CreateNewUser {
	
	@Test
	public void createUser()
	{
		JSONObject payload=new JSONObject();
		payload.put("name", "harry");
		payload.put("job", "QA");
		
		RestAssured.baseURI="https://reqres.in";
		 Response res=	given().log().all().body(payload.toJSONString())
		.headers("Content-Type","application/json")
		.when().post("api/users")
		.then().log().all().extract().response();
		 
//		String value= res.getHeader("Server");
//		
//		System.out.println(value); 
//	int code=	res.getStatusCode();
//	System.out.println(code);
  
		 System.out.println("The JSON response is");
		 System.out.println(res);
	ResponseBody obj=	 res.getBody();
	
	
	
	JsonProcessingEx jdata=obj.as(JsonProcessingEx.class);
		 
	String name=jdata.name;
	String job=jdata.job;
	
	System.out.println("Java Data is "+name);
	System.out.println("Job is  is "+job);
	
	Assert.assertEquals("harry",name,"Validating the name");
	Assert.assertEquals("QA",job,"Validating the job detail");	 
		 
	System.out.println("Test case passed");
		
		
		
		System.out.println();
		
		
		
		System.out.println("Test case passed");
	}
	
	
	

}
