package PayloadData;

public class Payload1 {
	
	public static String addDetails(String name,String job)
	{
		String details="{\r\n"
				+ "    \"name\": \""+name+"\",\r\n"
				+ "    \"job\": \""+job+"\"\r\n"
				+ "}";
		
		return details;
	}
	
	public static String addBook(String isbn,String aisle)
	{
		
		String payload="{\r\n"
				+ "\"name\":\"Learn Appium Automation with Java\",\r\n"
				+ "\"isbn\":\""+isbn+"\",\r\n"
				+ "\"aisle\":\""+aisle+"\",\r\n"
				+ "\"author\":\"John foe\"\r\n"
				+ "}";
		
		return payload;
		
		
		
	}
	
	
	
	
	
	
	
	
	
	
	

}
