package PayloadData;

import java.util.LinkedHashMap;
import java.util.Map;

public class CookiesData {
	
	public static Map SetCookiesData()
	{
		Map<String,Object> mp=new LinkedHashMap<String,Object>();
		mp.put("username","monty");
		mp.put("password","test@1234");
		return mp;
		
		
	}
	

}
