package Constants;

public class ConstantsVariable {
	
	public static final String PROPERTY_FILE_PATH="src\\main\\java\\GlobalData.properties";

}
