package StringInJava;

public class StringMethods6 {

	public static void main(String[] args) {
		
		int x=20;
		String str1=String.valueOf(x);
		System.out.println(str1+20);
		
		
		

	}

}
