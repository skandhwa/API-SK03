package StringInJava;

public class StringCreation {

	public static void main(String[] args) {
		
		///String literal
		String str="India";
		
	String str7=	str.concat("Republic");
		
		System.out.println(str7);
		
		String str1="India";
		
		
		///Using new Keyword
		
		String str2=new String("India");
		
		
		
		

	}

}
