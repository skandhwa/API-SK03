package StringInJava;

public class StringMethods5 {

	public static void main(String[] args) {
		
		String str="India is a democratic country";
		int x=str.indexOf("r",18);
		System.out.println(x);
		

	}

}
