package ArraysinJava;

public class ArrayDeclaration {

	public static void main(String[] args) {
		
		int a[]=new int[5];
		
		a[0]=10;
		a[1]=20;
		a[2]=30;
		a[3]=40;
		a[4]=60;
		a[5]=90;
		
		for(int i=0;i<a.length;i++)//i=0,0<5
		{
			System.out.println(a[i]);
		}
		
		System.out.println();
		System.out.println();
		
		int b[]= {23,34,31,45,67,88};
		for(int x:b)
		{
			System.out.println(x);
		}
		
		
		
		
		

	}

}
