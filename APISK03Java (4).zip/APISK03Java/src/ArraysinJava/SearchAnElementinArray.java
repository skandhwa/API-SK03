package ArraysinJava;

public class SearchAnElementinArray {
	public static int linearSearch(int []a,int k)
	{
		for(int i=0;i<a.length;i++)
		{
			if(a[i]==k)
			{
				return i;
			}
		}
		
		return -1;
	}

	public static void main(String[] args) {
		
		int a[]= {12,3,5,13,11,56,32,56,78,98};
		int k=199;
		
		System.out.println("Key found at index "+linearSearch(a,k));
		

	}

}
