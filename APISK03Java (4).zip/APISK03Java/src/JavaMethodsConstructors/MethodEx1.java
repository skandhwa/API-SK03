package JavaMethodsConstructors;

class Test
{
	int k;
	int j;
	
	
	void message()
	{
		System.out.println("This is message");
		k=20;
		j=30;
		
	}
	
	int sum()
	{
		k=40;
		int a=10;
		int b=20;
		int x=a+b;
		return x;
	}
	
	void test2()
	{
		a=40;
	}
	
	
	
}
public class MethodEx1 {
	
	MethodEx1()
	{
		//System.out.println("Hi");
	}
	
	void display()
	{
		System.out.println("Hello");
	}
	public static void main(String[] args) {
		
		MethodEx1 obj=new MethodEx1();
		obj.display();
		
		Test obj1=new Test();
		obj1.message();
		
	System.out.println(obj1.sum());	
		
		
		
		
		

	}

}
