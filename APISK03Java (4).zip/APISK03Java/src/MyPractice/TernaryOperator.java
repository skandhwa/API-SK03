package MyPractice;

public class TernaryOperator {

	public static void main(String[] args) {
		
		int a=10;
		
		a/=2;// a=a/8
		
		System.out.println("value of a is "+a);
		
		int b=14;
		int c=20;
		
		int max= (a>b)?a:b;
		
		System.out.println(max);
		
		int max1= a>b?(a>c?a:c) :(b>c?b:c);
		
		System.out.println(max1);
		
		
		
		
		

	}

}
