package MyPractice;

public class OperatorsinJava {

	public static void main(String[] args) {
		
		int a=5;
		int b=6;
		int k=7;
		
		
		
		int c= ++a + k-- + b++ + --a + --b + ++k;//37
		
		//    6 +  7 + 6   + 5 +6 + 7                        ///a=6,k=6,b=7
		
		System.out.println(c);
		
		
		
		
		
		
	}

}

	
