package MyPractice;

public class WhileLoopReverseaNumber {

	public static void main(String[] args) {
		
		
		int num=121;
		int n=num;
		int rev=0;
		while(num!=0)//67!=0//6!=0//0!=0
		{
			int r=num%10;///r=678%10, r=8//r=67%10=7 ///r=6%10=6
			rev=rev*10+r;// rev=8//rev=8*10+7=87//rev=87*10+6=876
			num=num/10;//num=67//num=67/10=6//num=6/10=0
			
		}
		
		System.out.println("Reverse of numbser is  "+rev );
		
		if(n==rev)
		{
			System.out.println("The number is palindrome");
		}
		else
		{
			System.out.println("The number is not  palindrome");
		}
		
		
		
		
		

	}

}
