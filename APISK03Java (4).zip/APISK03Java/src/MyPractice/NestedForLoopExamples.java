package MyPractice;

public class NestedForLoopExamples {

	public static void main(String[] args) {
		
		for(int i=0;i<=3;i++)//i=0,0<=3//i=1,1<=3//i=2,2<=3
		{
			for(int j=0;j<=3;j++)//
			{
				System.out.print(i+" ");//0//0//0//0//1//1//1//1//2
				System.out.println(j);//0//1//2//3//0//1//2//3
			}
			
		}
		

	}

}
