package MyPractice;

public class IfLoopExamples {

	public static void main(String[] args) {
		
		int x=10;
		if(x>7)
		{
			if(x>8)
			{
				if(x>19)
				{
					System.out.println("Hi");
				}
			}
		}
		
		System.out.println("Hello how r u");
		

	}

}
