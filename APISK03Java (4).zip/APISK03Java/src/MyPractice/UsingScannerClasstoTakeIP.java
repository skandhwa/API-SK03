package MyPractice;

import java.util.Scanner;

public class UsingScannerClasstoTakeIP {

	public static void main(String[] args) {
		
		int num1,num2;
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the first number");
		num1=sc.nextInt();
		System.out.println("Enter the second number");
		num2=sc.nextInt();
		int result=num1+num2;
		System.out.println("The sum is "+result);
		
		

	}

}
