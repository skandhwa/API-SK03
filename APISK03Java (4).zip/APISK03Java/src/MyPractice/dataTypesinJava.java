package MyPractice;

public class dataTypesinJava {

	public static void main(String[] args) {
		
		
		int x=2423432423432432432432432;
		boolean d=abc;
		
		byte v=128; ////-128 to +127
		
		short j=-32543;
		
		long k=22132132132132131L;
		
		char ch='AB';
		
		
		

	}

}
