package MyPractice;

public class FibonacciSeriesEx {

	public static void main(String[] args) {
	
		int n1=0;
		int n2=1;
		int n3;
		int count=12;
		System.out.print(n1+" "+n2);//0 1
		
		for(int i=2;i<count;i++)//i=2,2<12//i=3,3<12//i=4,4<12//i=5,5<12//i=6<
		{
			n3=n1+n2;//n3=0+1=1//n3=2//n3=3///n3=2+3=5//n3=8
			System.out.print(" "+n3);//1//2//3//5
			n1=n2;//n1=1//n1=1//n1=2//n1=3
			n2=n3;//n2=1//n2=2//n2=3//n2=5
			
		}
		
		
		

	}

}
