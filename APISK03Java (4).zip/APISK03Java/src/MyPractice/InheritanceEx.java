package MyPractice;

class Test4
{
	void display()
	{
		System.out.println("hello");
	}
}

class Test5 extends Test4
{
	void test()
	{
		System.out.println("Test method");
	}
}

class Test6 extends Test5
{
	void message()
	{
		System.out.println("Message method");
	}
}


public class InheritanceEx {

	public static void main(String[] args) {
		
		Test6 obj=new Test6();
		obj.display();
		obj.test();
		obj.message();
		
	}

}
