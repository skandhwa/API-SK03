package MyPractice;

public class ShiftOperatorExample {

	public static void main(String[] args) {
		
		System.out.println(150>>4); ///13/8
		

	}

}
