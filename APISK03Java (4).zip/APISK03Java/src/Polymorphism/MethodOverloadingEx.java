package Polymorphism;

class PoyEx
{
	static int add(int x,int y)
	{
		return x+y;
	}
	
	static float add(int x,float y)
	{
		return x+y;
	}
	
	static int add(int x,int y,int z)
	{
		return x+y+z;
	}
}
public class MethodOverloadingEx {

	public static void main(String[] args) {
		
	System.out.println(PoyEx.add(23, 56));	
	
	System.out.println(	PoyEx.add(34, 100,67));
	
	System.out.println	(PoyEx.add(23,45.6f));
	
		
		

	}

}
