package Polymorphism;

class Emp5
{
	static final int test(int x,int y)
	{
		return x+y;
	}
}

class Person2 extends Emp5
{
	int test(int x,int y)
	{
		return x+y;
	}
}

public class finalMethodexample {

	public static void main(String[] args) {
		
		Person2 obj=new Person2();
	System.out.println(obj.test(23,34));	
		

	}

}
