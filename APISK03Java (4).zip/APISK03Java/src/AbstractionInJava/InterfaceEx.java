package AbstractionInJava;

interface X
{
	void display();
	void test();
}

class Y implements X
{
	public void display()
	{
		System.out.println("hello");
	}
	
	public void test()
	{
		System.out.println("hi how r u");
	}
	
}
public class InterfaceEx {

	public static void main(String[] args) {
		
		Y obj=new Y();
		obj.display();
		obj.test();
		
		X ref=new Y();
		ref.display();
		ref.test();
		
		
		

	}

}
