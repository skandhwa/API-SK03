package OOpsConceptandSuperThis;

class Person
{
	int id;
	String name;
	Person(int i,String n)
	{
		id=i;
		name=n;
	}
}
class Emp4 extends Person
{
	float salary;
	Emp4(int id,String name,float s)
	{
		super(id,name);
		salary=s;
		
		
	}
	
	void display()
	{
		System.out.println(id+"  "+name+"  "+salary);
	}
	
}
public class SuperWithConstructor {

	public static void main(String[] args) {
		Emp4 obj=new Emp4(1234,"Rohan",56000f);
		obj.display();
		

	}

}
