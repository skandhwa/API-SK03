package OOpsConceptandSuperThis;

class Student6
{
	int roll;
	String name;
	String address;
	Student6(int roll,String name,String address)
	{
		this.roll=roll;
		this.name=name;
		this.address=address;
	}
	
	void display()
	{
		System.out.println(roll+" "+name+" "+address);
	}
	}


public class UsingThisKeyword {

	public static void main(String[] args) {
		
		Student6 obj=new Student6(1234,"Kunal","Kolkata");
		obj.display();
		
		
		

	}

}
